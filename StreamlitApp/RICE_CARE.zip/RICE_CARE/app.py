import streamlit as st
import os
from PIL import Image
from load_clients import UPLOAD_FOLDER
from symptom_description_generation import describer_agent
from candidate_and_knowledge_retrieval import retrieve_candidate_and_knowledge, get_candidates, get_visual_symptoms_list, get_visual_symptoms_by_candidate
from human_in_the_loop_reasoning import get_question_by_candidate, correct_class_name, questioning_agent
from rationale_advice_generation import get_context_by_candidate, advisory_agent

if "current_candidate" not in st.session_state:
    st.session_state.current_candidate = None

if "image_path" not in st.session_state:
    st.session_state.image_path = None

if "results" not in st.session_state:
    st.session_state.results = []

if "candidates" not in st.session_state:
    st.session_state.candidates = []

if "visual_symptoms" not in st.session_state:
    st.session_state.visual_symptoms = []

if "questions" not in st.session_state:
    st.session_state.questions = []

if "answers" not in st.session_state:
    st.session_state.answers = []

if "final_decision" not in st.session_state:
    st.session_state.final_decision = None

if "question_count" not in st.session_state:
    st.session_state.question_count = 0

if "uploader_key" not in st.session_state:
    st.session_state.uploader_key = 0

st.set_page_config(page_title="RICE-CARE", layout="centered")
st.title("🌾 RICE-CARE: Rice Disease and Pest Diagnosis")

uploaded_image = st.file_uploader(
    "Upload a crop image",
    type=["jpg", "jpeg", "png"],
    key=f"uploader_{st.session_state.uploader_key}"
)

image_path = ""
if uploaded_image is not None:
    image = Image.open(uploaded_image)
    st.image(image, caption="Uploaded Image", width="content")

    if st.button("Diagnose"):
        # Save image in project folder
        image_path = os.path.abspath(os.path.join(UPLOAD_FOLDER, uploaded_image.name))
        with open(image_path, "wb") as f:
            f.write(uploaded_image.getbuffer())

        st.session_state.current_candidate = None
        st.session_state.results = []
        st.session_state.candidates = []
        st.session_state.visual_symptoms = []
        st.session_state.questions = []
        st.session_state.answers = []
        st.session_state.question_count = 0
        st.session_state.final_decision = None
        st.session_state.image_path = image_path

        with st.spinner("Generating description...", show_time=True):
            sym_desc = describer_agent(st.session_state.image_path)

        st.success("✅ Description generated")

        # -----------------------------
        # 1. Show LLM description
        # -----------------------------
        # st.subheader("📝 Image Description")
        # st.write(sym_desc)

        # -----------------------------
        # 2. Hybrid search with desc
        # -----------------------------
        with st.spinner("🔍 Searching knowledge base...", show_time=True):
            results = retrieve_candidate_and_knowledge(image_path, sym_desc)

        st.success("✅ Search completed")

        if not results:
            st.error("❌ No relevant disease or pest found in the knowledge base.")
        else:
            st.session_state.results = results
            # -----------------------------
            # 3. Display search results
            # -----------------------------
            # st.subheader("📊 Retrieved Diseases / Pests")
            #
            # for i, r in enumerate(results, 1):
            #     st.markdown(f"### {i}. {r['name']}")
            #     st.write(f"**Type:** {r.get('type', 'N/A')}")
            #     st.write(f"**Score:** {r.get('score', 0):.4f}")
            #     st.write(r.get("text", ""))
            #     st.divider()
            st.rerun()


# -----------------------------
# Questioning Loop
# -----------------------------
if st.session_state.results and st.session_state.final_decision is None:

    if st.session_state.question_count >= 5:
        st.session_state.final_decision = "No Candidate"
        st.rerun()

    # Initialize candidates once
    if not st.session_state.candidates:
        st.session_state.candidates = get_candidates(st.session_state.results)
        st.session_state.visual_symptoms = get_visual_symptoms_list(st.session_state.results)

    # Select candidate only if not selected
    if st.session_state.current_candidate is None:
        with st.spinner("Picking best candidate...", show_time=True):
            candidate = questioning_agent.select_candidate(
                st.session_state.image_path,
                st.session_state.candidates,
                st.session_state.visual_symptoms,
                list(zip(st.session_state.questions, st.session_state.answers))
            )

        if not candidate:
            st.error("❌ No candidate found.")
            st.stop()

        candidate = correct_class_name(candidate, st.session_state.candidates)
        st.session_state.current_candidate = candidate

    candidate = st.session_state.current_candidate
    question = get_question_by_candidate(candidate)

    if not question:
        st.error("❌ No question found.")
        st.stop()

    #st.subheader(f"🔎 Checking: {candidate}")
    st.subheader("Please answer the following question:")
    st.write(question)

    farmer_input = st.radio(
        "Please select your answer:",
        ["Yes", "No"],
        horizontal=True,
        key="farmer_input"
    )

    if st.button("Submit Answer"):

        with st.spinner("Evaluating answer...", show_time=True):

            # Increase question count
            st.session_state.question_count += 1

            formatted_question = f"Question for candidate {candidate}: {question}"
            formatted_answer = f"Farmer's answer {candidate}: {farmer_input}"

            st.session_state.questions.append(formatted_question)
            st.session_state.answers.append(formatted_answer)
            visual_symptom = get_visual_symptoms_by_candidate(st.session_state.results, candidate)

            decision, reasoning = questioning_agent.evaluate_answer(
                st.session_state.image_path,
                candidate,
                visual_symptom,
                list(zip(st.session_state.questions, st.session_state.answers))
            )


            if decision == "confirm":
                st.session_state.final_decision = candidate

                with st.spinner("Generating Advice...", show_time=True):
                    context_text = get_context_by_candidate(
                        st.session_state.results,
                        candidate,
                        reasoning
                    )
                    st.session_state.advice = advisory_agent(context_text)

            elif decision == "reject":
                st.session_state.candidates = [
                    c for c in st.session_state.candidates if c != candidate
                ]
                st.warning(f"❌ Rejected: {candidate}")

            if decision != "confirm":
                st.session_state.current_candidate = None

        st.rerun()

if st.session_state.final_decision is not None:

    if st.session_state.final_decision != "No Candidate":
        st.subheader(f"✅ Diagnosis Result: {st.session_state.final_decision}")
        st.write(st.session_state.get("advice", ""))
    else:
        st.error("❌ Max question limit exceeded! Please try again later or contact experts.")


    if st.button("🔴 Finish"):

        img_path = st.session_state.get("image_path")

        if img_path and os.path.isfile(img_path):
            os.remove(img_path)

            # Increment uploader key → forces reset
            st.session_state.uploader_key += 1

            # Clear everything except uploader_key
            keys_to_keep = ["uploader_key"]
            for key in list(st.session_state.keys()):
                if key not in keys_to_keep:
                    del st.session_state[key]

        st.rerun()