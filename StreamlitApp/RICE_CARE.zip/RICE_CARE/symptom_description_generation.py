import base64
from load_clients import clientAI, MODEL

def describer_agent(image_path):

  with open(image_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("utf-8")

  prompt = """You are describing a rice plant image like a farmer reporting what is visible.
              Rules:
              1) Write only one short sentence, maximum 20 words.
              2) Describe only visible symptoms or physical damage.
              3) You must mention the affected plant part such as leaf, panicle, stem, sheath, or root in the same sentence.
              4) Mention key visible details ONLY if they are clearly visible, such as lesion color, center color, border color, color change, spot or lesion size, shape, pattern, and exact location.
              5) You may include patterns (if only clearly visible) like water-soaked marks, patchy, scraped areas, streaks, wavy edges, holes, masses, or droppings, etc.
              6) You may include shapes (if only clearly visible) like elongated, round, oval, spindle-shaped, ball, irregular, etc.
              7) Do not guess causes. Do not add background explanation.
              8) Do NOT mention lesions, spots, borders, or patterns unless they are clearly visible.
              9) Do NOT add background explanation.
              10) Do not mention any disease name.
              11) Do not mention the words disease, pest, or insect.
              12) Output only the sentence and nothing else."""

  completion = clientAI.chat.completions.create(
            model = MODEL,
            temperature = 0.2,
            top_p = 1.0,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",  # Still use 'image_url', but with base64 data
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{b64}"
                            }
                        }
                    ]
                }
            ]
        )

  desc = completion.choices[0].message.content

  return desc