from collections import defaultdict
import numpy as np
from PIL import Image
import torch
from qdrant_client import models
from load_clients import clientQD
from models import clip_model, processor, dense_encoder

class RetrieverAgent:

    def __init__(
        self,
        client,
        collection_name="hybrid_collection",
        img_collection_name="VDB_DP_IMAGES",
        name_collection="name_to_entry",
        dense_encoder=None,
        sparse_encoder=None,
        image_encoder_fn=None,
        dense_vector_name="dense",
        sparse_vector_name="sparse",
        rrf_k=10,
        fusion_depth = 30,
    ):

        self.client = client

        self.collection_name = collection_name
        self.img_collection_name = img_collection_name
        self.name_collection = name_collection

        self.dense_encoder = dense_encoder
        self.sparse_encoder = sparse_encoder
        self.image_encoder_fn = image_encoder_fn

        self.dense_vector_name = dense_vector_name
        self.sparse_vector_name = sparse_vector_name

        self.rrf_k = rrf_k
        self.fusion_depth = fusion_depth

    # ============================================================
    # Individual Retrievals
    # ============================================================

    def _dense_retrieve(self, query_text):

        dense_vec = list(self.dense_encoder.embed([query_text]))[0]

        response = self.client.query_points(
            collection_name=self.collection_name,
            query=dense_vec,
            using=self.dense_vector_name,
            limit=self.fusion_depth,
        )

        # print("Dense: ")
        # print(response.points)
        # print("\n")

        return response.points

    def _sparse_retrieve(self, query_text):

        sparse_vec = list(self.sparse_encoder.embed([query_text]))[0]

        response = self.client.query_points(
            collection_name=self.collection_name,
            query=models.SparseVector(**sparse_vec.as_object()),
            using=self.sparse_vector_name,
            limit=self.fusion_depth,
        )

        # print("BM25: ")
        # print(response.points)
        # print("\n")

        return response.points

    def _image_retrieve(self, query_image_path):

        image_vec = self.image_encoder_fn(query_image_path)
        image_vec = np.array(image_vec).flatten().tolist()

        response = self.client.query_points(
            collection_name=self.img_collection_name,
            query=image_vec,
            limit=self.fusion_depth,
        )

        # print("Image: ")
        # print(response.points)
        # print("\n")

        return response.points

    # ============================================================
    # External RRF
    # ============================================================

    def _rrf_fusion(self, ranked_lists):

        fused_scores = defaultdict(float)
        point_lookup = {}

        for ranked_list in ranked_lists:

            # ----------------------------------------------------
            # Keep BEST point per disease for this retrieval branch
            # ----------------------------------------------------
            best_per_name = {}

            for point in ranked_list:

                payload = point.payload or {}

                key = payload.get("name", "")

                if key == "":
                    continue

                if (
                    key not in best_per_name
                    or point.score > best_per_name[key].score
                ):
                    best_per_name[key] = point

            # ----------------------------------------------------
            # Apply RRF using disease-level ranking
            # ----------------------------------------------------
            deduped_points = sorted(
                best_per_name.values(),
                key=lambda x: x.score,
                reverse=True,
            )

            for rank, point in enumerate(deduped_points, start=1):

                key = point.payload.get("name", "")

                fused_scores[key] += 1.0 / (self.rrf_k + rank)

                # keep best overall representative point
                if (
                    key not in point_lookup
                    or point.score > point_lookup[key].score
                ):
                    point_lookup[key] = point

        # --------------------------------------------------------
        # Final fused ranking
        # --------------------------------------------------------
        ranked_items = sorted(
            fused_scores.items(),
            key=lambda x: x[1],
            reverse=True,
        )

        fused_points = []

        for key, fused_score in ranked_items[:self.fusion_depth]:

            point = point_lookup[key]

            point.score = float(fused_score)

            fused_points.append(point)

        return fused_points

    # ============================================================
    # Hybrid Retrieval Variants
    # ============================================================

    def _hybrid_retrieve(self, query_text):

        dense_points = self._dense_retrieve(query_text)

        sparse_points = self._sparse_retrieve(query_text)

        return self._rrf_fusion(
            [dense_points, sparse_points],
        )

    def _dense_image_retrieve(
        self,
        query_text,
        query_image_path,
    ):

        dense_points = self._dense_retrieve(
            query_text
        )

        image_points = self._image_retrieve(
            query_image_path
        )

        return self._rrf_fusion(
            [dense_points, image_points]
        )

    def _sparse_image_retrieve(
        self,
        query_text,
        query_image_path
    ):

        sparse_points = self._sparse_retrieve(
            query_text
        )

        image_points = self._image_retrieve(
            query_image_path
        )

        return self._rrf_fusion(
            [sparse_points, image_points]
        )

    def _full_mm_retrieve(
        self,
        query_text,
        query_image_path,
    ):

        dense_points = self._dense_retrieve(
            query_text
        )

        sparse_points = self._sparse_retrieve(
            query_text
        )

        image_points = self._image_retrieve(
            query_image_path
        )

        return self._rrf_fusion(
            [
                dense_points,
                sparse_points,
                image_points,
            ]
        )

    # ============================================================
    # Post Processing
    # ============================================================

    def _process_results(self, points, top_k):

        best_by_name = {}

        for point in points:

            payload = point.payload or {}

            name = payload.get("name", "unknown")
            typ = payload.get("type", "unknown")
            text = payload.get("text", "").strip()

            if (
                name not in best_by_name
                or point.score > best_by_name[name]["score"]
            ):

                best_by_name[name] = {
                    "id": point.id,
                    "score": point.score,
                    "name": name,
                    "type": typ,
                    "matched_sentence": text,
                }

        return sorted(
            best_by_name.values(),
            key=lambda x: x["score"],
            reverse=True,
        )[:top_k]

    # ============================================================
    # Metadata Attachment
    # ============================================================

    def _attach_metadata(self, results):

        for result in results:

            name = result["name"]

            if name == "unknown":

                result["sections_text"] = ""
                result["visual_symptoms"] = ""

                continue

            name_result = self.client.query_points(
                collection_name=self.name_collection,
                query_filter=models.Filter(
                    must=[
                        models.FieldCondition(
                            key="name",
                            match=models.MatchValue(value=name),
                        )
                    ]
                ),
                limit=1,
            )

            if name_result.points:

                payload = name_result.points[0].payload

                result["sections_text"] = payload.get(
                    "sections_text",
                    "",
                )

                result["visual_symptoms"] = payload.get(
                    "visual_symptoms",
                    "",
                )

            else:

                result["sections_text"] = ""
                result["visual_symptoms"] = ""

        return results

    # ============================================================
    # Public Retrieval API
    # ============================================================

    def retrieve(self, query_text = None, query_image_path = None, top_k=10):

        if self.dense_encoder and self.sparse_encoder and self.image_encoder_fn:
            points = self._full_mm_retrieve(query_text, query_image_path)

        elif self.dense_encoder and self.sparse_encoder:
            points = self._hybrid_retrieve(query_text)

        elif self.dense_encoder and self.image_encoder_fn:
            points = self._dense_image_retrieve(query_text, query_image_path)

        elif self.sparse_encoder and self.image_encoder_fn:
            points = self._sparse_image_retrieve(query_text, query_image_path)

        elif self.dense_encoder:
            points = self._dense_retrieve(query_text)

        elif self.sparse_encoder:
            points = self._sparse_retrieve(query_text)

        elif self.image_encoder_fn:
            points = self._image_retrieve(query_image_path)

        else:
            raise ValueError("No encoder available! Provide dense or sparse encoder.")

        results = self._process_results(points, top_k)
        results = self._attach_metadata(results)

        return results


def encode_image_clip(path):

    img = Image.open(path).convert("RGB")

    inputs = processor(
        images=img,
        return_tensors="pt"
    )

    with torch.no_grad():

        vision_outputs = clip_model.vision_model(
            pixel_values=inputs["pixel_values"]
        )

        pooled = vision_outputs.pooler_output

        feat = clip_model.visual_projection(
            pooled
        )

    feat = torch.nn.functional.normalize(
        feat,
        p=2,
        dim=-1,
    )

    feat = feat.squeeze().cpu().numpy()

    return feat.tolist()

def retrieve_candidate_and_knowledge(image_path, sym_desc):
  retriever = RetrieverAgent(
    client=clientQD,
    dense_encoder=dense_encoder,
    image_encoder_fn=encode_image_clip,
  )

  results = retriever.retrieve(sym_desc, image_path, top_k=10)
  return results

def get_candidates(results):
    return [
        r["name"]
        for r in results
        if r.get("name")
    ]

def get_visual_symptoms_list(results):
    return [
        {
            "name": r.get("name", ""),
            "type": r.get("type", ""),
            "visual_symptoms": r.get("visual_symptoms", "")
        }
        for r in results
    ]


def get_visual_symptoms_by_candidate(results, candidate_name):
    for r in results:
        if r.get("name") == candidate_name:
            return r.get("visual_symptoms", "")

    return ""

