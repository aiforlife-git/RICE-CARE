import os

import streamlit as st
from dotenv import load_dotenv
from openai import OpenAI
from qdrant_client import QdrantClient
from pathlib import Path

load_dotenv()

MODEL = os.getenv("MODEL")
# =========================================================
# OPENAI CLIENT
# =========================================================

@st.cache_resource
def load_openai_client():

    api_key = os.getenv("OPENAI_API_KEY")

    if not api_key:
        raise ValueError(
            "OPENAI_API_KEY is not set in the environment."
        )

    return OpenAI(api_key=api_key)

# =========================================================
# LOCAL QDRANT CLIENT
# =========================================================

@st.cache_resource
def load_qdrant_client_local():

    qdrant_path = Path(__file__).parent / os.getenv("QDRANT_PATH")

    if not qdrant_path:
        raise ValueError(
            "QDRANT_PATH is not set in the environment."
        )

    return QdrantClient(path=qdrant_path)


# =========================================================
# QDRANT CLIENT
# =========================================================

@st.cache_resource
def load_qdrant_client_cloud():

    qdrant_url = os.getenv("QDRANT_URL")
    qdrant_api_key = os.getenv("QDRANT_API_KEY")

    if not qdrant_url:
        raise ValueError(
            "QDRANT_URL is not set in the environment."
        )

    if not qdrant_api_key:
        raise ValueError(
            "QDRANT_API_KEY is not set in the environment."
        )

    return QdrantClient(
        url=qdrant_url,
        api_key=qdrant_api_key
    )

clientAI = load_openai_client()
clientQD = load_qdrant_client_local()
quesDB = os.getenv("QUES_DB_PATH")
UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER")