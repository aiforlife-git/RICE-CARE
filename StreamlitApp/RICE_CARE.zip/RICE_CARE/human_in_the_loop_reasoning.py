from load_clients import clientAI, MODEL, quesDB
import re
import json
from rapidfuzz import process, fuzz
from pathlib import Path

def correct_class_name(predicted_name, VALID_CLASSES, threshold=80):
    """
    Corrects VLM-generated disease/pest names by
    matching them to the closest valid class name.

    Args:
        predicted_name (str): VLM output disease name.
        threshold (int): Minimum similarity score.

    Returns:
        str: Corrected disease name.
    """

    if not predicted_name:
        return predicted_name

    # Remove leading/trailing spaces
    text = predicted_name.strip()

    # Insert spaces before capital letters
    # e.g., BacterialLeaf -> Bacterial Leaf
    text = re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', text)

    # Remove multiple spaces
    text = re.sub(r'\s+', ' ', text)

    # Find closest valid class
    match, score, _ = process.extractOne(
        text,
        VALID_CLASSES,
        scorer=fuzz.WRatio
    )

    # Return official class name if similarity is high enough
    if score >= threshold:
        return match

    return text

def get_question_by_candidate(candidate):
    """
    Return the first question for the given candidate.
    No index required.
    No session storage.
    """

    question_file = Path(__file__).parent / quesDB

    with open(question_file, "r", encoding="utf-8") as f:
        question_data = json.load(f)  # this is a LIST

    for item in question_data:
        if item["name"] == candidate:
            questions = item.get("set_a", [])
            return questions[0] if questions else None

    return None

import base64


class QuestioningAgent:

    def __init__(self, clientAI, MODEL):
        self.clientAI = clientAI
        self.MODEL = MODEL

    def select_candidate(
        self,
        image_path,
        candidates,
        visual_symptoms,
        conversation_history
    ):

        b64 = ""
        candidate_name = ""

        with open(image_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("utf-8")

        system_prompt = (
            "You are an agricultural diagnosis assistant for rice crops. "
            "Follow the user-provided rules exactly and do not introduce your own decision criteria."
        )

        candidate_selection_prompt = f"""Candidate list (ranked): {candidates}
                                                  Visual context for each candidate: {visual_symptoms}
                                                  Farmer's answers so far: {conversation_history}

                                                  Consider only the context provided above.

                                                  IMPORTANT: You must output ONLY the candidate name exactly as listed in the candidate list.
                                                  Do NOT output any reasoning, explanation, step-by-step text, or extra characters.
                                                  Do NOT add anything before, after, or around the candidate name.

                                                  Selection rules:
                                                  A. Use the image and visual context as the primary basis for selection.
                                                  B. Give strong priority to candidates whose affected plant part matches the visible symptom location.
                                                  For example, if symptoms are mainly on leaves, prefer leaf diseases or leaf pest damage over panicle or stem diseases.
                                                  C. The ranking provides a relevance prior and should influence your choice.
                                                  D. Prefer higher-ranked candidates when they are reasonably consistent with the image.
                                                  E. Select a lower-ranked candidate only if it matches the image and plant part clearly better.
                                                  F. If the image is unclear or symptoms are partially visible, rely more on plant part match and overall similarity.
                                                  G. Do not require every listed symptom to be visible.
                                                  H. You must select exactly one candidate from the provided candidate list.
                                                  I. You are not allowed to answer no match, unknown, or none.
                                                  J. You must not invent or output any name that is not in the candidate list.
                                                  K. Even if the image is unclear, choose the closest matching candidate from the list.

                                                  Your task (for internal reasoning only):
                                                  1) Review the image to identify the main affected plant part and visible symptoms.
                                                  2) Compare with each candidate’s visual context.
                                                  3) Select the most relevant candidate using best visual similarity to the described symptoms, plant part match, and ranking preference.
                                                  4) Exact symptom match is not required; partial or approximate similarity is acceptable.
                                                  5) Do not perform reasoning or make any diagnosis decision.
                                                  6) Output only the selected candidate name.

                                                  Output format (strict):
                                                  Candidate: <selected candidate name>
                                                  No other text is allowed.
                                                  """

        messages = [
            {
                "role": "system",
                "content": system_prompt
            },
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": candidate_selection_prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{b64}"
                        }
                    }
                ]
            }
        ]

        response = self.clientAI.chat.completions.create(
            model=self.MODEL,
            temperature=0.0,
            top_p=1.0,
            messages=messages
        )
        llm_response = response.choices[0].message.content.strip()

        if llm_response.lower().startswith("candidate:"):
            candidate_name = llm_response.split(":", 1)[1].strip().strip("'").strip('"')

        return candidate_name

    def evaluate_answer(
        self,
        image_path,
        current_candidate,
        visual_symptoms,
        conversation_history
    ):

        b64 = ""
        decision = ""
        reasoning = ""

        with open(image_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("utf-8")

        system_prompt = (
            "You are an agricultural diagnosis assistant for rice crops. "
            "Follow the user-provided rules exactly and do not introduce your own decision criteria."
        )

        llm_prompt = f"""Current candidate: {current_candidate}
                              Visual context for the candidate: {visual_symptoms}
                              Farmer's answers so far: {conversation_history}

                              Consider the context provided above.

                              Evidence hierarchy:
                              Farmer answers carry greater importance than image information and must guide the decision.
                              Image information may be used only to support or question conclusions drawn from farmer answers, but must not override a clear farmer answer.
                              Do not reinterpret or soften a clear denial using image information.

                              Your task:
                              1) Review the image to understand the visual context.
                              2) Analyze the question(s) and their relevant farmer’s answer(s) so far.
                              2) Use image information only as supporting context when interpreting farmer answers.
                              3) Decide whether the combined evidence supports or contradicts the current candidate, giving priority to farmer answers when evidence conflicts.
                              4) You must not guess or decide based on image information alone.
                              5) You must output exactly one decision: [confirm] or [reject].
                              6) Reasoning must contain at most five complete sentences in plain text.
                              7) Do not use any formatting symbols such as **, *, _, backticks, or bullets.

                              Output format:
                              Reasoning: <plain text reasoning>
                              Decision: [confirm] or [reject]
                              Name: <candidate name>
                              """

        messages = [
            {
                "role": "system",
                "content": system_prompt
            },
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": llm_prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{b64}"
                        }
                    }
                ]
            }
        ]

        response = self.clientAI.chat.completions.create(
            model=self.MODEL,
            temperature=0.0,
            top_p=1.0,
            messages=messages
        )

        llm_response = response.choices[0].message.content.strip()

        for line in llm_response.split("\n"):

            if "[confirm]" in line.lower():
                decision = "confirm"

            elif "[reject]" in line.lower():
                decision = "reject"

            elif "[continue]" in line.lower():
                decision = "continue"

            if line.lower().startswith("reasoning:"):
                reasoning = line.split(":", 1)[1].strip()

        return decision, reasoning


questioning_agent = QuestioningAgent(
    clientAI=clientAI,
    MODEL=MODEL
)