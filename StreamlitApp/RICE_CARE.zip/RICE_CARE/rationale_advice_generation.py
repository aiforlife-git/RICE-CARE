from load_clients import clientAI, MODEL

def get_context_by_candidate(results, candidate_name, reasoning):
    """
    Return section_text ONLY for the selected candidate.
    """
    for r in results:
        if r["name"] == candidate_name:
            text = [f"Candidate Type: {r.get("type", "")}", f"Predicted: {r["name"]}", f"Raw reasoning: {reasoning}", ""]
            text.append(r.get("sections_text", ""))
            return "\n".join(text)

    return None  # if not found

def advisory_agent(context_text):

  system_prompt = (
      "You are an agricultural assistant helping rice farmers. "
      "Use only the information provided in the context.\n\n"
      f"Context:\n{context_text}\n\n"
      "If the answer cannot be found in the context, reply: "
      "'Please contact a human expert.'"

  )

  vlm_prompt = (
      "Based on the confirmed diagnosis in the context, provide a short explanation for the farmer.\n\n"

      "Your response should include:\n"
      "1. What is likely affecting the plant.\n"
      "2. Why you think this is the problem.\n"
      "3. What the farmer should do next.\n\n"

      "For the reason:\n"
      "- Use information from both the farmer's observations and the image-related observations.\n"
      "- Mention only evidence supporting the diagnosed problem.\n"
      "- Do not discuss diseases that were ruled out.\n"
      "- Explain the reason in simple everyday language.\n\n"

      "For the advice:\n"
      "- Use the information provided in the context.\n"
      "- Give practical actions the farmer can take.\n"
      "- Do not invent recommendations.\n\n"

      "Use simple, natural language that a farmer can easily understand.\n"
      "Avoid scientific or technical terms whenever possible.\n"
      "Keep the response concise.\n"
      "Start with a friendly sentence."
  )

  messages = [
                {
                    "role": "system",
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": vlm_prompt
                }
            ]

  response = clientAI.chat.completions.create(
                          model=MODEL,
                          temperature = 0.4,
                          top_p = 0.9,
                          messages=messages
                      )
  return response.choices[0].message.content.strip()