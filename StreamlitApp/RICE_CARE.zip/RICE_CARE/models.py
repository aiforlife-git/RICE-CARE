import os
import streamlit as st
from dotenv import load_dotenv

from fastembed import TextEmbedding, SparseTextEmbedding
from transformers import CLIPModel, CLIPProcessor

load_dotenv()

HF_token = os.getenv("HF_API_Read")

if not HF_token:
    st.error("Hugging Face API token not found.")
    st.stop()


# =========================================================
# LOAD DENSE + SPARSE ENCODERS
# =========================================================

@st.cache_resource
def load_encoders():

    dense_model_name = "sentence-transformers/all-MiniLM-L6-v2"
    #sparse_model_name = "Qdrant/bm25"

    dense_encoder = TextEmbedding(
        model_name=dense_model_name,
        token=HF_token
    )

    return dense_encoder

    # sparse_encoder = SparseTextEmbedding(
    #     model_name=sparse_model_name,
    #     token=HF_token
    # )

    #return dense_encoder, sparse_encoder

# =========================================================
# LOAD CLIP
# =========================================================

@st.cache_resource
def load_clip():

    clip_model = CLIPModel.from_pretrained(
        "openai/clip-vit-base-patch32",
        token=HF_token
    )

    processor = CLIPProcessor.from_pretrained(
        "openai/clip-vit-base-patch32",
        token=HF_token
    )

    return clip_model, processor

clip_model, processor = load_clip()
dense_encoder = load_encoders()